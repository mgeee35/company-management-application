namespace Infrastructure.Data.Postgres.EntityFramework.Configurations;

public class EmployeeRoleConfiguration
{
    
}