namespace Business.Models.Response
{
    public class DepartmentResponseDto
    {
        public int Id { get; set; } = default!;
        public string Name { get; set; } = default!;
        
    }
}
