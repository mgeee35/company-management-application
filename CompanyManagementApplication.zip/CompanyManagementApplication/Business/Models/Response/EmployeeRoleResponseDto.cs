namespace Business.Models.Response
{
    public class EmployeeRoleResponseDto
    {
        public int EmployeeId { get; set; } = default!;
        public int RoleId { get; set; } = default!;
        
    }
}
