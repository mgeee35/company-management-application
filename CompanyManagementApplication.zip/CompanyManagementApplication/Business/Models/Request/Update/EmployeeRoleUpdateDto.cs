namespace Business.Models.Request.Update
{
    public class EmployeeRoleUpdateDto
    {
        public int EmployeeId { get; set; } = default!;
        public int RoleId { get; set; } = default!;
    }
}
