namespace Business.Models.Request.Update
{
    public class DepartmentUpdateDto
    {
        public string Name { get; set; } = default!;
    }
}
