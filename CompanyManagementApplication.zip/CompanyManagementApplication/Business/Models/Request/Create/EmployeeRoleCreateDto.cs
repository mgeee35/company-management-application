namespace Business.Models.Request.Create
{
    public class EmployeeRoleCreateDto
    {
        public int EmployeeId { get; set; } = default!;
        public int RoleId { get; set; } = default!;
    }
}
