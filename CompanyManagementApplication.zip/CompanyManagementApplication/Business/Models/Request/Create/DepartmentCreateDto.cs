namespace Business.Models.Request.Create
{
    public class DepartmentCreateDto
    {
        public string Name { get; set; } = default!;
    }
}
