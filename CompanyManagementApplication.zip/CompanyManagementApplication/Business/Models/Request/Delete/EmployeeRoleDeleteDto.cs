namespace Business.Models.Request.Delete
{
    public class EmployeeRoleDeleteDto
    {
        public int EmployeeId { get; set; } = default!;
        public int RoleId { get; set; } = default!;
    }
}
