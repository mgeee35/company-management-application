namespace Business.Models.Request.Delete
{
    public class DepartmentDeleteDto
    {
        public string Name { get; set; } = default!;
    }
}
